"""
Migration v1: Đồng bộ cấu trúc DB cũ với database.py hiện tại
- Tạo các bảng còn thiếu: settings, user_warehouses, sales_gps_log, debt_payments, migrations
- Thêm cột thiếu: products.warehouse_id, import_order_items.warehouse_id, export_order_items.warehouse_id
- Đồng bộ dữ liệu warehouse_id từ parent orders vào order_items
- Cập nhật quantity_available = quantity_in_stock - quantity_reserved
- Tạo INDEX nếu chưa có
- KHÔNG làm mất dữ liệu hiện có

Chạy: python migration_v1.py
"""
import sqlite3
import shutil
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "warehouse.db"


def log(msg: str):
    print(f"[MIGRATION] {msg}")


def backup_db():
    backup_path = DB_PATH.with_suffix(f".db.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    shutil.copy2(DB_PATH, backup_path)
    log(f"Backup DB tại: {backup_path}")
    return backup_path


def migrate():
    if not DB_PATH.exists():
        log("DB chưa tồn tại, không cần migrate")
        return

    backup_db()
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")  # 30 giây timeout chờ lock
    conn.execute("PRAGMA foreign_keys=OFF")  # Tạm tắt FK để dễ dàng ALTER TABLE
    c = conn.cursor()

    try:
        # ============================
        # 1. TẠO CÁC BẢNG CÒN THIẾU
        # ============================
        log("=== Bước 1: Tạo bảng còn thiếu ===")

        # 1a. settings
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='settings'")
        if not c.fetchone():
            log("Tạo bảng settings...")
            c.execute("""CREATE TABLE settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                allow_negative_stock INTEGER NOT NULL DEFAULT 0,
                ncc_debt_limit REAL DEFAULT 0,
                kh_debt_limit REAL DEFAULT 0,
                updated_at TEXT DEFAULT (datetime('now','localtime'))
            )""")
            c.execute("""
                INSERT INTO settings (id, allow_negative_stock)
                VALUES (1, 0)
            """)
            log("  Đã tạo bảng settings + insert default")
        else:
            log("  Bảng settings đã tồn tại")

        # 1b. user_warehouses
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='user_warehouses'")
        if not c.fetchone():
            log("Tạo bảng user_warehouses...")
            c.execute("""CREATE TABLE user_warehouses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                warehouse_id INTEGER NOT NULL,
                created_at TEXT DEFAULT (datetime('now','localtime')),
                UNIQUE(user_id, warehouse_id),
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (warehouse_id) REFERENCES warehouses(id) ON DELETE CASCADE
            )""")
            log("  Đã tạo bảng user_warehouses")
        else:
            log("  Bảng user_warehouses đã tồn tại")

        # 1c. sales_gps_log
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sales_gps_log'")
        if not c.fetchone():
            log("Tạo bảng sales_gps_log...")
            c.execute("""CREATE TABLE sales_gps_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                accuracy REAL DEFAULT 0,
                address TEXT,
                note TEXT,
                created_at TEXT DEFAULT (datetime('now','localtime')),
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )""")
            log("  Đã tạo bảng sales_gps_log")
        else:
            log("  Bảng sales_gps_log đã tồn tại")

        # 1d. debt_payments
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='debt_payments'")
        if not c.fetchone():
            log("Tạo bảng debt_payments...")
            c.execute("""CREATE TABLE debt_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                partner_type TEXT NOT NULL,
                partner_id INTEGER NOT NULL,
                order_type TEXT NOT NULL,
                order_id INTEGER,
                payment_date TEXT NOT NULL,
                amount REAL NOT NULL,
                payment_method TEXT DEFAULT 'cash',
                reference_number TEXT,
                notes TEXT,
                created_at TEXT DEFAULT (datetime('now','localtime')),
                created_by INTEGER,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )""")
            log("  Đã tạo bảng debt_payments")
        else:
            log("  Bảng debt_payments đã tồn tại")

        # 1e. migrations (để ghi nhận version)
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='migrations'")
        if not c.fetchone():
            log("Tạo bảng migrations...")
            c.execute("""CREATE TABLE migrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version TEXT NOT NULL,
                applied_at TEXT DEFAULT (datetime('now','localtime'))
            )""")
            log("  Đã tạo bảng migrations")
        else:
            log("  Bảng migrations đã tồn tại")

        conn.commit()

        # ============================
        # 2. THÊM CỘT THIẾU
        # ============================
        log("=== Bước 2: Thêm cột thiếu ===")

        # 2a. products.warehouse_id
        c.execute("PRAGMA table_info(products)")
        cols = {row[1] for row in c.fetchall()}
        if "warehouse_id" not in cols:
            log("Thêm cột warehouse_id vào products...")
            # Thêm cột (nullable)
            c.execute("ALTER TABLE products ADD COLUMN warehouse_id INTEGER")
            # Set default = kho đầu tiên
            c.execute("SELECT id FROM warehouses WHERE is_active=1 ORDER BY id LIMIT 1")
            wh = c.fetchone()
            default_wh_id = wh['id'] if wh else 1
            c.execute("UPDATE products SET warehouse_id=? WHERE warehouse_id IS NULL", (default_wh_id,))
            log(f"  Đã thêm warehouse_id, gán mặc định = {default_wh_id}")
        else:
            log("  Cột products.warehouse_id đã tồn tại")

        # 2b. import_order_items.warehouse_id
        c.execute("PRAGMA table_info(import_order_items)")
        cols = {row[1] for row in c.fetchall()}
        if "warehouse_id" not in cols:
            log("Thêm cột warehouse_id vào import_order_items...")
            c.execute("ALTER TABLE import_order_items ADD COLUMN warehouse_id INTEGER")
            # Đồng bộ từ import_orders
            c.execute("""
                UPDATE import_order_items
                SET warehouse_id = (
                    SELECT io.warehouse_id FROM import_orders io
                    WHERE io.id = import_order_items.order_id
                )
                WHERE warehouse_id IS NULL
            """)
            log("  Đã thêm warehouse_id và đồng bộ từ import_orders")
        else:
            log("  Cột import_order_items.warehouse_id đã tồn tại")

        # 2c. export_order_items.warehouse_id
        c.execute("PRAGMA table_info(export_order_items)")
        cols = {row[1] for row in c.fetchall()}
        if "warehouse_id" not in cols:
            log("Thêm cột warehouse_id vào export_order_items...")
            c.execute("ALTER TABLE export_order_items ADD COLUMN warehouse_id INTEGER")
            # Đồng bộ từ export_orders
            c.execute("""
                UPDATE export_order_items
                SET warehouse_id = (
                    SELECT eo.warehouse_id FROM export_orders eo
                    WHERE eo.id = export_order_items.order_id
                )
                WHERE warehouse_id IS NULL
            """)
            log("  Đã thêm warehouse_id và đồng bộ từ export_orders")
        else:
            log("  Cột export_order_items.warehouse_id đã tồn tại")

        conn.commit()

        # ============================
        # 3. CẬP NHẬT quantity_available
        # ============================
        log("=== Bước 3: Cập nhật quantity_available ===")
        c.execute("SELECT COUNT(*) as cnt FROM inventory")
        total = c.fetchone()['cnt']
        if total > 0:
            c.execute("""
                UPDATE inventory SET
                    quantity_available = ROUND(quantity_in_stock - COALESCE(quantity_reserved, 0), 2),
                    updated_at = ?
                WHERE id > 0
            """, (datetime.now().isoformat(),))
            affected = c.connection.total_changes
            log(f"  Đã cập nhật quantity_available cho {total} rows inventory")
        else:
            log("  Bảng inventory trống, bỏ qua")

        conn.commit()

        # ============================
        # 4. TẠO INDEXES
        # ============================
        log("=== Bước 4: Tạo Indexes ===")
        indexes = [
            ("idx_inv_tx_product_wh_date", "inventory_transactions(product_id, warehouse_id, created_at)"),
            ("idx_import_orders_date_status", "import_orders(order_date, status)"),
            ("idx_export_orders_date_status", "export_orders(order_date, status)"),
            ("idx_import_order_items_order", "import_order_items(order_id)"),
            ("idx_export_order_items_order", "export_order_items(order_id)"),
        ]
        for idx_name, idx_def in indexes:
            c.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {idx_def}")
        log(f"  Đã kiểm tra/tạo {len(indexes)} indexes")

        conn.commit()

        # ============================
        # 5. GHI NHẬN VERSION
        # ============================
        log("=== Bước 5: Ghi nhận version ===")
        # Kiểm tra xem version đã được ghi chưa
        c.execute("SELECT COUNT(*) as cnt FROM migrations WHERE version='1.0.0'")
        if c.fetchone()['cnt'] == 0:
            c.execute("INSERT INTO migrations (version) VALUES ('1.0.0')")
            log("  Đã ghi nhận migration version 1.0.0")
        else:
            log("  Migration version 1.0.0 đã tồn tại")

        conn.commit()
        log("=== MIGRATION HOÀN TẤT ===")

    except Exception as e:
        conn.rollback()
        log(f"LỖI: {e}")
        print(f"[MIGRATION] Rollback do lỗi: {e}")
        raise
    finally:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.close()


if __name__ == "__main__":
    migrate()